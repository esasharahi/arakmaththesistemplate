# arakmaththesistemplate


This is a sample for typesetting math thesis based on Arak university style ; albeit you can change it for your own purposes.


==Glossaries==


For glossaries, we recommend typesetting by hand (as provided in Cls file) unto using glossary package (xepersian has some bugs with this famous package). Moreover; we used \linebreak[3] instead of \ \ for glossary paragraphs in our style. In very Persian styles (i.e. Tabriz template) it is common to use \ \ and the result is some bad warnings "Overfull hbox". In the case of plurality, it makes page breaking and this is not a good news. One can get more data in this kind of warning on the web.


==Xelatex for Xepersian==


If you are using multiple engines, it is useful to hold % !TEX TS-program = XeLaTeX in the first line. If not, you can restrain it by commenting it with %. One can find more about these kinds of comments by searching "magic comments" on the web (or in texstudio help).


==Indexing==


Oh, do not forget that if you are using an index for contents of important words, you MUST update index contents before the final build. In some editors it has a default shortcut (for example in texmaker F12 updates index contents) and in general it  depends on your editor. You can do this simply by "makeindex filename" from a commandline too. Search the web for more information. It is required a double build updating for any new ref too. Is it clear? :) Search the web anyway.


==Fonts==


We use three fonts only: XB Yas (for text typesetting), PGaramond (for math typesetting) and IranNastaliq for acknowledgement. For quick access, these fonts have been uploaded. You SHOULD put these in your  directory of the fonts (if you have not them). 



==Printing==


You must print your final PDF file. In our template, the conditional statements names  are in another color (blue) only; though you can change them to black in Cls file. Moreover; you may have some colorful pictures, plots and etc in your PDF file. If you want to print in  a black/white mode, you SHOULD turn all the colors off in your PDF file. So, what are the suitable ways? 

1) You can uncomment the line 
%\selectcolormodel{gray} 
in the preamble of the arak_thesis.tex and build PDF. You see that all of the colors changed to the gray. After printing, this color is closed to black. We recommend this way, when the tex file is accessible. 

2) Go to the command-line. You can use "gs" or "convert" commands in terminal to create a new white/black copy of your PDF file. "Convert" package is accessible via "imagemagick" package in Gnu/Linux; Moreover both of "gs" and "imagemagick" are accessible in windows too. For example 
" convert -density 150 -threshold 50% arak_thesis.pdf output.pdf" 
do that. For more info, search the web. 

3) Use online converters. For example http://greyscalepdf.com/ is a very good online converter. 

4) Gimp, photoshop and variety of PDF readers/creators can do this too. But the problem scale is smaller than those. ;)

Note: I am switching on ConTeXt; an absolutely better typesetter than Xepersian. 


==Contact us==


==Acknowledgments==


Special thanks to Saeed Mirzakhani for his help about Github to me. Find his page: https://github.com/LinArcX?tab=repositories

Special thanks to Farshad Firuzi for hints; one of the best C and Perl programmers that I know. You can find him easily. :)

Special thanks to Arak university math students for their feedbacks. Any additional/further comments are truly valued. 

Good luck and enjoy LaTeX.

ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

A cheat sheet for some common warnings and errors. 

ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

|| To avoid  some warnings like "Token not allowed in a PDF string", use \texorpdfstring as a widget of hyperref package.  These warnings may caused by half-spacing (or any command that has not a good sync with bookmarks). For example, try 

\section{
        \texorpdfstring{جبرهای لی-راین\,هارت و جبرهای لی تعمیم\,یافته}
                   {}}
                   
                   
and 



\section{جبرهای لی-راین\,هارت و جبرهای لی تعمیم\,یافته}

separately. Moreover, \texorpdfstring is a useful tool to refer to an address with a different name. search the web.

|| In order to detect the reason of some warnings like "badbox overfull \hbox too wide" use optional [draft] argument in your documentclass. It will produce/make some small black lines where the lines of your document are too long to fit the horizontal space based on your document geometry which will therefore cause a/some warning/s.
